package jumpin.view.constants;

/**
 * 
 * @author Giuseppe
 *
 */
public class FontConstants {

	public static final String DEFAULT_FONT = "Arial";

	public static final String MENU_FONT = "Verdana";

	public static final String BUTTON_FONT = DEFAULT_FONT;
}
