package play;

import jumpin.controller.launch.LaunchController;

public class GUI {

	public static void main(String[] args) {
		LaunchController launcher= new LaunchController();
		launcher.startMenu();
	}

}