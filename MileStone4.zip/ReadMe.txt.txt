Please read Deliverables/Game Manual.pdf or Game Manual.txt before launching the game.

For a more detailed readMe, visit https://github.com/JulianMendoza/JumpIN/blob/master/README.md