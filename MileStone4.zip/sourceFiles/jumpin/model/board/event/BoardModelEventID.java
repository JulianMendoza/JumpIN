package jumpin.model.board.event;

/**
 * 
 * @author Giuseppe
 *
 */
public class BoardModelEventID {

	public static final int MOVE_GENERIC = 0;

	public static final int MOVE_ON_RABBIT_HOLE = 1;

	public static final int MOVE_OFF_RABBIT_HOLE = 2;

}
