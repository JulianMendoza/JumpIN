package jumpin.view;

/**
 * 
 * @author Giuseppe
 *
 */
public interface AbstractFrame {

	public void populate();

}
